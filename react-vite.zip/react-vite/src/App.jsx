import React from 'react';
import Parent from './Q1/parent';


function App() {
  return (
    <div>
      <h1>Parent-Child Communication Example</h1>
      <Parent />
    </div>
  );
}

export default App;
