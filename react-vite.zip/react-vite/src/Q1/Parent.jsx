import React, { useState } from 'react';
import Child from './child';

function Parent() {
  const [message, setMessage] = useState("Hello, I am in SMVITA");

  const updateMessage = (newMessage) => {
    setMessage(newMessage);
  };

  return (
    <div>
      <h2>Parent Component</h2>
      <h2>Message: {message}</h2>
      <Child onUpdate={updateMessage} />
    </div>
  );
}

export default Parent;

