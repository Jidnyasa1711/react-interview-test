import React from 'react';

function Child({ onUpdate }) {
  const sendNewMessage = () => {
    onUpdate("Hi, I am in Idigicloud");
  };

  return (
    <div>
      <h3>Child Component</h3>
      <button onClick={sendNewMessage}>Update Parent Message</button>
    </div>
  );
}

export default Child;

  